
/* 
 * File:   main.cpp
 * Author: Cesar Augusto Napuri de la Cruz
 * Codigo: 20211692
 */

#include "Biblioteca.h"
using namespace std;

int main(int argc, char** argv) {

    Biblioteca bli;
    
    bli.carga();
    bli.muestra();
    bli.prueba(8);
    
    return 0;
}
