
/* [/]
 >> Project:    Aegleseeker
 >> File:       main.cpp
 >> Author:     CyndxTs o.0?!
[/] */

#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
using namespace std;
#include "Partida.h"

//
int main(int argc, char** argv) {
    Partida p;
    p.iniciarNuevaPartida();
    
    return 0;
}
