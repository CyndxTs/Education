
/*/
 * Projecto:            HeaderConverter
 * Nombre del Archivo:  declaraciones.h
 * Autor:               CyndxTs o.0?!
/*/

#ifndef DECLARACIONES_H
#define DECLARACIONES_H

// Declaracion de Constantes
const int num_OP    = 30;   // Cantidad Maxima de Operadores Predefinidos
const int num_KW    = 45;   // Cantidad Maxima de Palabras Clave Predefinidas
const int max_OP    = 50;   // Maximo Numero de Operandos por Asignacion
const int max_PM    = 25;   // Maximo Numero de Parametros en Funcion/Operando
const int med_ID    = 100;  // Medida Maxima de Identificador de Elemento
const int med_KW    = 50;   // Medida Maxima de Identificador de Palabra Clave de Elemento
const int med_OP    = 10;   // Medida Maxima de Identificador de Operador
const int med_Linea = 60;   // Medida de Linea de Terminal

// Definicion de "KeyWord" [Palabra Clave]
typedef struct{
    bool esCompuesta;
    char identificador[med_KW]{};
} KeyWord;
// Definicion de "Operador"
typedef struct{
    bool esAcotablePorLetras;
    char identificador[med_OP]{};
} Operador;
// Definicion de "Parametro"
typedef struct{
    int posConjunta = 0;
    char keyWord[med_KW]{};
    char identificador[med_ID]{};
} Parametro;
// Definicion de "Funcion"
typedef struct{
    int numParametros = 0;
    int posApertura = 0;
    Parametro parametros[max_PM]{};
} Funcion;
// Definicion de "Operando"
typedef struct{
    bool esFuncion = false;
    int posConjunta = 0;
    int posApertura = 0;
    int numParametros = 0;
    char identificador[med_ID]{};
    char operador[med_OP]{};
    Parametro parametros[max_PM]{};
} Operando;
// Definicion de "Asignacion"
typedef struct{
    bool esAgrupada = false;
    int posApertura = 0;
    int numOperandos = 0;
    Operando operandos[max_OP]{};
} Asignacion;
// Definicion de "Declaracion"
typedef struct{
    char tipo;
    char keyWord[med_KW]{};
    char identificador[med_ID]{}; 
    Asignacion asignacion;
    Funcion funcion;
} Declaracion;
// Definicion de "Nodo"
typedef struct nodo{
    struct nodo *proximo;
    Declaracion declaracion;
} Nodo;
// Declaracion de "LSE"
typedef struct{
    Nodo *inicial = nullptr;
} LSE;

#endif /* DECLARACIONES_H */
