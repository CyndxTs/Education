
/*/
 * Projecto:            HeaderConverter
 * Nombre del Archivo:  converter.cpp
 * Autor:               CyndxTs o.0?!
/*/

#include <iomanip>
#include <iostream>
#include <fstream>
#include <cstring>
using namespace std;
#include "converter.h"

                      /* - / Funciones en 'main()' / - */

// Modulo de Transcripcion de Archivo hacia Cabezera
void transcribirHaciaCabezera(ifstream &archFuente,ofstream &archSalida){
    // Declaracion de Variables
    LSE ListaDeDeclaraciones; Declaracion declaracion;
    // Validacion de Realizacion de Procesamiento
    if(mostrarFunciones or mostrarVariablesGlobales){
        // Iterativa del Proceso de Transcripcion
        while(1){
            // Proceso de Busqueda e Inserción de Proxima KeyWord de Declaracion
            almacenarProximaKeyWord(archFuente,declaracion.keyWord,true,false);
            // Validacion de Fin de Archivo
            if(archFuente.eof()) break;
            // Almacenamiento de Identificador de Declaracion
            almacenarProximoIdentificador(archFuente,declaracion);
            // Procesamiento de Declaracion Encontrada
            procesarDeclaracion(archFuente,ListaDeDeclaraciones,declaracion);
        }
        // Impresion de Transcipcion
        imprimirLista(archSalida,ListaDeDeclaraciones);
    } else emitirWarning('E'); // Emision de Warning por falta de Resultados
}

                      /* - / Funciones Principales / - */

// Modulo de Procesmiento por Tipo de Declaracion
void procesarDeclaracion(ifstream &archFuente,LSE &ListaDeDeclaraciones,
                         Declaracion &declaracion){
    // Seleccion de Proceso por Tipo de Declaracion
    if(declaracion.tipo == 'F'){
        // Validacion de Procesamiento de Funciones
        if(mostrarFunciones){
            Funcion funcion;
            funcion.posApertura = strlen(declaracion.keyWord) +
                                  strlen(declaracion.identificador);
            obtenerParametros(archFuente,funcion);
            declaracion.funcion = funcion;
            insertarOrdenado(ListaDeDeclaraciones,declaracion);
        } else while (archFuente.get() != ')');
        // Descarte de Procedimientos
        archFuente>>ws;
        if(archFuente.get() == '{') descartarHastaDelimitador(archFuente,'}');
    }else if(declaracion.tipo == 'A'){
        // Validacion de Procesamiento de Variables Globales
        if(mostrarVariablesGlobales){
            Asignacion asignacion;
            asignacion.posApertura = strlen(declaracion.keyWord) +
                                     strlen(declaracion.identificador);
            obtenerOperandos(archFuente,asignacion);
            declaracion.asignacion = asignacion;
            insertarOrdenado(ListaDeDeclaraciones,declaracion);
        } else descartarHastaDelimitador(archFuente,';'); // Descarte de Datos
    }
}
// Modulo de Impresion de Lista Simplemente Enlazada de Declaraciones
void imprimirLista(ofstream &archSalida,LSE lse){
    // Declaracion de Variables
    Nodo *nAux = lse.inicial;
    // Iterativa del Proceso de Impresion
    while (nAux != nullptr){
        archSalida<<endl<<nAux->declaracion.keyWord;
        archSalida<<nAux->declaracion.identificador;
        // Seleccion de Tipo de Impresion por Tipo de Declaracion
        switch(nAux->declaracion.tipo){
            case 'F':
                imprimirFuncion(archSalida,nAux->declaracion.funcion);
                break;
            case 'A':
                imprimirAsignacion(archSalida,nAux->declaracion.asignacion);
                break;
        }
        nAux = nAux->proximo;
    }
}

                      /* - / Funciones Secundarias / - */

// Modulo de Insercion Ordenada de Declaracion en Lista Simplemente Enlazada
void insertarOrdenado(LSE &lse,Declaracion declaracion){
    // Declaracion & Inicializacion de Elementos
    bool insertar;int diff_TP,diff_KW,diff_ID;
    Nodo *nNuevo = new Nodo,*nAux = lse.inicial,*nAnt = nAux;
    nNuevo->declaracion = declaracion;
    nNuevo->proximo = nullptr;
    // Validacion de lista Vacia | Validacion de Realizacion de Ordenamiento
    if(lse.inicial == nullptr) lse.inicial = nNuevo;
    else if(ordenarDeclaraciones){
        while(nAux != nullptr){
            diff_TP = declaracion.tipo - nAux->declaracion.tipo;
            diff_KW = strcmp(declaracion.keyWord,nAux->declaracion.keyWord);
            diff_ID = strcmp(declaracion.identificador,
                             nAux->declaracion.identificador);
            switch(tipoOrdenamiento){
                case 'A':
                    insertar = diff_TP < 0 or (diff_TP == 0 and
                               (diff_KW < 0 or
                               (diff_KW == 0 and diff_ID < 0)));
                    break;
                case 'D':
                    insertar = diff_TP > 0 or (diff_TP == 0 and 
                              (diff_KW > 0 or
                              (diff_KW == 0 and diff_ID > 0)));
                    break;
                default:
                    emitirWarning('O');
                    break;
            }
            if(insertar){
                if(nAnt == nAux){
                    nNuevo->proximo = lse.inicial;
                    lse.inicial = nNuevo;
                } else{
                    nAnt->proximo = nNuevo;
                    nNuevo->proximo = nAux;
                }
                break;
            }
            nAnt = nAux;
            nAux = nAux->proximo;
        }
        if(nAux == nullptr) nAnt->proximo = nNuevo;
    } else{
        while(nAux != nullptr){
            nAnt = nAux;
            nAux = nAux->proximo;
        }
        nAnt->proximo = nNuevo;
    }
}
// Modulo de Impresion de Funcion en Formato PREDETERMINADO
void imprimirFuncion(ofstream &archSalida,Funcion funcion){
    // Declaracion de Variables
    Parametro parametro; bool existeID,tieneModificador,separarElementos;
    int posApertura = funcion.posApertura; int posColumna = posApertura;
    int numParametros = funcion.numParametros;
    // Validacion de Error por Limite de Margen [L]
    if(ajustarHaciaMargen and posColumna > limiteMargen) emitirWarning('L');
    // Iterativa del Proceso de Impresion de Funcion
    if(numParametros == 0) archSalida<<')';
    else{
        for(int p = 0;p < numParametros;p++){
            parametro = funcion.parametros[p];
            existeID = (strlen(parametro.identificador) != 1);
            tieneModificador = esModificador(parametro.keyWord[
                                             strlen(parametro.keyWord)-1]);
            separarElementos = existeID and not tieneModificador;
            if(p == numParametros-1) parametro.posConjunta++;
            if(separarElementos) parametro.posConjunta++;
            procesarAjusteHaciaMargen(archSalida,posApertura,
                                      parametro.posConjunta,posColumna);
            archSalida<<parametro.keyWord;
            if(separarElementos) archSalida.put(' ');
            archSalida<<parametro.identificador;
        }
    }
    archSalida<<simboloLimite<<endl;
}
// Modulo de Impresion de Asignacion en Formato PREDETERMINADO
void imprimirAsignacion(ofstream &archSalida,Asignacion asignacion){
    // Declaracion de Variables
    int posApertura = asignacion.posApertura,posColumna = posApertura;
    int numOperandos = asignacion.numOperandos;
    int posSubApertura,posConjunta,numParametros;
    Operando operando; Parametro parametro;
    // Validacion de Agrupacion
    if(asignacion.esAgrupada) archSalida<<'{';
    // Iterativa del Proceso de Impresion de Asignacion
    for(int op = 0;op < numOperandos;op++){
        operando = asignacion.operandos[op];
        posConjunta = operando.posConjunta;
        if(operando.esFuncion) posConjunta+=operando.parametros[0].posConjunta;
        if(not procesarAjusteHaciaMargen(archSalida,posApertura,posConjunta,
                                         posColumna)){
            if(op > 0 and not asignacion.esAgrupada) archSalida.put(' ');
        }
        archSalida<<operando.identificador;
        if(operando.esFuncion){
            numParametros = operando.numParametros;
            posSubApertura = posApertura + operando.posApertura;
            for(int pm = 0;pm < numParametros;pm++){
                parametro = operando.parametros[pm];
                procesarAjusteHaciaMargen(archSalida,posSubApertura,
                                          parametro.posConjunta,posColumna);
                archSalida<<operando.parametros[pm].identificador;
            }
        }
        if(not asignacion.esAgrupada) archSalida.put(' ');
        archSalida<<operando.operador;
    }
    archSalida<<endl;
}

                       /* - / Funciones Derivadas / - */

// Modulo de Validacion y Ejecucion de Ajuste Hacia Margen
bool procesarAjusteHaciaMargen(ofstream &archSalida,int posApertura,
                               int posConjunta,int &posColumna){
    // Validacion de Ajuste a Margen
    if(ajustarHaciaMargen and posColumna + posConjunta > limiteMargen){
        archSalida<<endl<<setw(posApertura)<<' ';
        posColumna = posApertura + posConjunta;
        return true;
    }
    posColumna += posConjunta;
    return false;
}

                       /* - / Funciones Auxiliares / - */

// Modulo de Apertura de Archivos IFSTREAM
ifstream abrirArchivo_IFS(const char *nombArch) {
    // Declaracion de Variables
    ifstream archIFS(nombArch,ios::in);
    fstream archFS(nombArch,ios::in|ios::out);
    // Validacion de Apertura
    if(not archIFS.is_open()){
        emitirWarning('A');
        cout<<"El Archivo '"<<nombArch<<"' no fue encontrado en el directorio.";
        cout<<endl;
        exit(1);
    }
    // Correccion Rapida de Archivo por Enter
    archFS.seekg(-1,ios::end);
    if(archFS.get() != '\n') archFS<<endl;
    // Retorno de Archivo
    return archIFS;
}
// Modulo de Apertura de Archivos OFSTREAM
ofstream abrirArchivo_OFS(const char *nombArch) {
    ofstream archOFS(nombArch, ios::out);
    if(not archOFS.is_open()){
        emitirWarning('A');
        cout<<"El Archivo '"<<nombArch<<"' no fue encontrado en el directorio.";
        cout<<endl;
        exit(1);
    }
    return archOFS;
}
// Modulo de Validacion de Letra como 'Agrupador'
bool esAgrupador(char letra){
    for(int i = 0;agrupadores[i][0];i++){
        if (esAperturador(letra) or esDelimitador(letra)) return true;
    }
    return false;
}
// Modulo de Validacion de Letra como Agrupador
bool esAperturador(char letra){
    for(int i = 0;agrupadores[i][0];i++){
        if(letra == agrupadores[i][0]) return true;
    }
    return false;
}
// Modulo de Validacion de Letra como Agrupador
bool esSeparador(char letra){
    for(int i = 0;separadores[i];i++) if(letra == separadores[i]) return true;
    return false;
}
// Modulo de Validacion de Letra Como "Delimitador"
bool esDelimitador(char letra){
    for(int i = 0;agrupadores[i][0];i++){
        if(letra == agrupadores[i][1]) return true;
    }
    return false;
}
// Modulo de Validacion de Letra como "Espaciador"
bool esEspaciador(char letra){
    for(int i = 0;espaciadores[i];i++){
        if(letra == espaciadores[i]) return true;
    }
    return false;
}
// Modulo de Validacion de Letra como "Modificador"
bool esModificador(char letra){
    for(int i=0;modificadores[i];i++) if(letra == modificadores[i]) return true;
    return false;
}
// Modulo de Busqueda de Agrupador Opuesto
char obtenerAgrupadorInverso(char agrupador) {
    for (int i = 0;i < agrupadores[i][0];i++){
        if (agrupadores[i][0] == agrupador) return agrupadores[i][1];
        else if (agrupadores[i][1] == agrupador) return agrupadores[i][0];
    }
    return 0;
}
// Modulo SOBRECARGADO de Almacenamiento de Parametros de Funcion [Variante: Funciones]
void obtenerParametros(ifstream &archFuente,Funcion &funcion){
    // Declaracion de Variables
    Parametro parametro;
    // Iterativa del Proceso de Extraccion & Impresion de Parametros
    for(int p = 0;1;p++){
        archFuente>>ws;
        // Validacion de Fin de Funcion
        if(archFuente.get() == ')') break;
        archFuente.unget();
        // Proceso de Extraccion de Palabra Clave
        almacenarProximaKeyWord(archFuente,parametro.keyWord,true,true);
        // Proceso de Extraccion de Identificador de Parametro
        almacenarProximoIdentificador(archFuente,suprimirVariables,
                                      parametro.identificador);
        // Actualizacion de Datos de Parametro de Funcion
        parametro.posConjunta = strlen(parametro.keyWord) +
                                strlen(parametro.identificador);
        funcion.parametros[p] = parametro;
        funcion.numParametros++;
    }
}
// Modulo SOBRECARGADO de Almacenamiento de Parametros de Funcion [Variante: Operandos]
void obtenerParametros(ifstream &archFuente,Operando &operando){
    // Declaracion de Variables
    Parametro parametro;
    // Iterativa del Proceso de Almacenamiento de Parametros
    for(int p = 0;1;p++){
        archFuente>>ws;
        // Proceso de Extraccion de Identificador de Parametro
        almacenarProximoIdentificador(archFuente,false,
                                      parametro.identificador);
        // Actualizacion de Datos de Parametro de Funcion
        parametro.posConjunta = strlen(parametro.identificador);
        operando.parametros[p] = parametro;
        operando.numParametros++;
        // Validacion de Fin de Funcion
        if(archFuente.get() == ')') break;
    }
}
// Modulo de Almacenamiento de Operandos de Asignacion
void obtenerOperandos(ifstream &archFuente,Asignacion &asignacion){
    // Proceso de Validacion de Agrupacion
    archFuente>>ws;
    if(archFuente.get() == '{'){
        asignacion.esAgrupada = true;
        asignacion.posApertura++;
    }else archFuente.unget();
    // Iterativa del Proceso de Almacenamiento de Operandos
    for(int op = 0;1;op++){
        archFuente>>ws;
        if(archFuente.get() == '/') validarDescartarPorComentario(archFuente);
        else archFuente.unget();
        almacenarProximoOperando(archFuente,asignacion.operandos[op]);
        asignacion.numOperandos++;
        if(archFuente.get() == ';') break;
    }
}
// Modulo de Busqueda e Inserción de Proxima Cadena Clave
void almacenarProximaKeyWord(ifstream &archFuente,char *cadClave,
                             bool sobreescribir,bool esParametro){
    // Declaracion de Variables
    bool kwValidos[med_KW]{},hayEquivalencias; char letra;
    // Iterativa del Proceso de Busqueda e Insercion
    for (int i = 0;1;i++){
        letra = archFuente.get();
        if (archFuente.eof()) return; // Validacion de Fin de Archivo
        hayEquivalencias = false;
        procesarDescarteEspecial(archFuente,letra);
        // Filtracion de Cadena Clave por Posicion de Letra
        for(int posKw = 0;keyWords[posKw].identificador[0];posKw++){
            if(kwValidos[posKw] or i == 0){
                if(keyWords[posKw].identificador[i] == letra){
                    if(keyWords[posKw].identificador[i+1] == '\0'){
                        if(not sobreescribir){
                            strcat(cadClave," ");
                            strcat(cadClave,keyWords[posKw].identificador);
                        } else strcpy(cadClave,keyWords[posKw].identificador);
                        if(keyWords[posKw].esCompuesta){
                            almacenarProximaKeyWord(archFuente,cadClave,
                                                        false,esParametro);
                        } else{
                            obtenerModificadoresDeKW(archFuente,cadClave,
                                                     esParametro);
                        }
                        return;
                    }
                    kwValidos[posKw] = true;
                    hayEquivalencias = true;
                } else kwValidos[posKw] = false;
            }
        }
        // Validacion de Existencia de Coincidencias
        if (not hayEquivalencias) i = -1;
    }
}
// Modulo de Extraccion de Modificadores de Palabra Clave
void obtenerModificadoresDeKW(ifstream &archFuente,char *cadClave,
                              bool esParametro) {
    // Declaracion de Variables
    int medida = strlen(cadClave); char letra;
    // Iterativa del Proceso de Extraccion de Modificadores
    for (int i = medida; 1; i++) {
        archFuente>>ws;
        letra = archFuente.get();
        // Validacion por Fin de Modificador & Posicion
        if (not esModificador(letra)) {
            if (i == medida and not esParametro) {
                cadClave[i] = ' ';
                i++;
            }
            cadClave[i] = 0;
            archFuente.unget();
            break;
        } else if (i == medida) {
            cadClave[i] = ' ';
            i++;
        }
        cadClave[i] = letra;
    }
}
// Modulo SOBRECARGADO de Extraccion de Proximo Identificador [Variante: Declaraciones]
void almacenarProximoIdentificador(ifstream &archFuente,
                                   Declaracion &declaracion){
    // Declaracion de Variables
    char letra = 0;
    // Iterativa del Procesamiento del Identificador de la Funcion/Variable
    for(int i = 0;1;i++){
        letra = archFuente.get();
        // Filtro de Espaciadores
        if (not esEspaciador(letra)){
            declaracion.identificador[i] = letra;
            // Validacion de Espacios Extra || Validaciones por Finalizacion
            if(letra == '('){
                declaracion.tipo = 'F';
                declaracion.identificador[i+1] = 0;
                break;
            }else if(letra == '=' or letra == ';'){
                declaracion.tipo = 'A';
                declaracion.identificador[i] = 0;
                strcat(declaracion.identificador," = ");
                break;
            }else if(esAgrupador(letra)){
                i++;
                letra = obtenerAgrupadorInverso(letra);
                almacenarHastaDelimitador(archFuente,declaracion.identificador,
                                          letra,i);
                i--;
            }
        } else if (letra == '\n') emitirWarning('P'); // Warning por Particion
        else i--;
    }
}
// Modulo Sobrecargado de Extraccion de Proximo Identificador [Variante: Parametros]
void almacenarProximoIdentificador(ifstream &archFuente,bool suprimir,
                                   char *identificador){
    // Declaracion de Variables
    int i = 0; char letra;
    // Iterativa del Proceso de Extraccion
    while(1){
        letra = archFuente.get();
        // Validacion por Tipo de Letra
        if (not esEspaciador(letra)){
            if(letra == '/') validarDescartarPorComentario(archFuente);
            else if(esAperturador(letra)){
                identificador[i] = letra;
                i++;
                letra = obtenerAgrupadorInverso(letra);
                almacenarHastaDelimitador(archFuente,identificador,letra,i);
            }else if(esSeparador(letra) or esDelimitador(letra)){
                identificador[i] = letra;
                identificador[i+1] = 0;
                archFuente.unget();
                break;
            }else if(not suprimir){
                identificador[i] = letra;
                i++;
            }
        }
    }
}
// Modulo de Extraccion de Proximo Operando en Asignacion;
void almacenarProximoOperando(ifstream &archFuente,Operando &operando){
    // Declaracion de Variables
    bool opValidos[num_OP]{},hayEquivalencias;
    char letra,anterior = 0,anteriorRelativo = 0;
    // Iterativa del Proceso de Busqueda e Insercion
    for (int i = 0,j = 0;1;i++){
        hayEquivalencias = false;
        letra = archFuente.get();
        // Filtro de Espaciadores
        if(not esEspaciador(letra)){
            operando.identificador[i] = letra;
            operando.identificador[i+1] = 0;
            // Seleccion de Proceso de Almacenamiento por Tipo de Letra
            if(esSeparador(letra)){
                operando.posConjunta = strlen(operando.identificador) +
                                       strlen(operando.operador);
                archFuente.unget();
                return;
            }else if(esAperturador(letra)){
                if(letra == '(' and anterior >= '0' and anterior <= 'z'){
                    operando.esFuncion = true;
                    operando.posApertura = strlen(operando.identificador);
                    obtenerParametros(archFuente,operando);
                }else{
                    i++;
                    letra = obtenerAgrupadorInverso(letra);
                    almacenarHastaDelimitador(archFuente,
                                              operando.identificador,letra,i);
                    i--;
                }
            }else{
                // Iterativa de Doble Busqueda // Iterativa de Filtracion de Operador
                for(int k = 0;k < 2;k++){
                    for(int posOp=0;operators[posOp].identificador[0];posOp++){
                        if(opValidos[posOp] or j == 0){
                            if(operators[posOp].identificador[j] == letra){
                                if(operators[posOp].identificador[j+1] == '\0'
                                    and (operators[posOp].esAcotablePorLetras or
                                    (anterior<='A' or anterior >='z'))){
                                    separarOperadorDeIdentificador(operando,
                                                operators[posOp].identificador);
                                    archFuente.unget();
                                    return;
                                }
                                opValidos[posOp] = true;
                                hayEquivalencias = true;
                            } else opValidos[posOp] == false;
                        }
                    }
                    // Seleccion de Proceso Por Equivalencias
                    if(not hayEquivalencias){
                        j = 0;
                        anterior = anteriorRelativo;
                    } else{
                        anteriorRelativo = letra;
                        break;
                    }
                }
            }
        }else{
            archFuente>>ws;
            i--;
        }
        // Seleccion de Proceso Por Equivalencias
        if(hayEquivalencias) j++;
        else anteriorRelativo = letra;
    }
}
// Modulo De Separacion de Operador e Identificador
void separarOperadorDeIdentificador(Operando &operando,const char *operador){
    // Declaracion de Variables
    int medOperador = strlen(operador) + 1;
    int posCorreccion = strlen(operando.identificador) - medOperador + 1;
    // Proceso de Separacion
    operando.identificador[posCorreccion] = 0;
    strcpy(operando.operador,operador);
    operando.posConjunta = strlen(operando.identificador) +
                           strlen(operando.operador);
}
// Modulo de Extracción de Cadena hasta Delimitador [Formato de Extracción: PREDETERMINADO]
void almacenarHastaDelimitador(ifstream &archFuente,char *cadena,
                               char delimitador,int &posCad){
    // Declaracion de Variables
    bool existeLetra = false; int medContenido = 1; char letra = 0;
    // Iterativa del Proceso de Almacenamiento
    while (1){
        letra = archFuente.get();
        // Validacion de Letra Obtenida & Delimitador Fijado
        if (letra != '\n'){
            medContenido++;
            if (delimitador == '"' or not esEspaciador(letra)){
                cadena[posCad] = letra;
                posCad++;
                if (letra != ' ' and letra != delimitador) existeLetra = true;
            }
            // Validacion Existencia de Subnivel
            if (esAperturador(letra) and not(delimitador == 39 or
                delimitador == '"')){
                almacenarHastaDelimitador(archFuente,cadena,
                                          obtenerAgrupadorInverso(letra),
                                          posCad);
            }
        }
        // Validacion de Cierre
        if(letra == delimitador or (letra == ';' and delimitador != 39 and 
            delimitador != '"')){
            if(delimitador == 39 and medContenido > 2 and not existeLetra){
                cadena[posCad-1] = ' ';
                cadena[posCad] = delimitador;
                posCad++;
            }
            cadena[posCad] = 0;
            break;
        }
    }
}
// Modulo de Descarte de Cadena hasta Delimitador [Formato de Descarte: PREDETERMINADO]
void descartarHastaDelimitador(ifstream &archFuente,char delimitador) {
    // Declaracion de Variables
    char letra = 0;
    // Iterativa del Proceso de Descarte
    while (1) {
        letra = archFuente.get();
        // Validacion de Cierre
        if (letra == delimitador) break;
        // Validacion Existencia de Subnivel
        if ((delimitador != 39 and delimitador != '"') and
            (esAgrupador(letra) and letra != '<' and letra != '>')){
            letra = obtenerAgrupadorInverso(letra);
            descartarHastaDelimitador(archFuente,letra);
        }
    }
}
// Modulo de Validacion y Seleccion de Proceso de Descarte por Tipo de Letra
void procesarDescarteEspecial(ifstream &archFuente,char letra){
    if(esEspaciador(letra)) archFuente>>ws;
    else if(letra == '#') while(archFuente.get() != '\n');
    else if (esAgrupador(letra) and not esDelimitador(letra)){
        descartarHastaDelimitador(archFuente,obtenerAgrupadorInverso(letra));
    } else if (letra == '/') validarDescartarPorComentario(archFuente);
}
// Modulo de Validacion & Ejecucion de Descarte de Comentario
void validarDescartarPorComentario(ifstream &archFuente){
    // Declaracion de Variables
    char letra = archFuente.get();
    // Validacion para Proceso de Descarte
    if (letra == '/') while (archFuente.get() != '\n');
    else if (letra == '*') {
        while (1) {
            while (archFuente.get() != '*');
            letra = archFuente.get();
            if (letra == '/') break;
        }
    }
    
}
// Modulo de Emision de Errores Comunes
void emitirWarning(char seleccion){
    switch (seleccion) {
        case 'A':
            cout<<setw((med_Linea+17)/2)<<"ERROR DE APERTURA"<<endl;
            break;
        case 'E':
            cout<<setw((med_Linea+16)/2)<<"SIN RESULTADOS"<<endl;
            cout<<"No existe error como tal.. Signifca que se ha desactivado";
            cout<<endl<<"la muestra de ambos tipos de declaracion.."<<endl;
            cout<<"Acciones recomendadas:"<<endl;
            cout<<"[A] Activar alguno de los controladores de muestra."<<endl;
            break;
        case 'L':
            cout<<setw((med_Linea+16)/2)<<"ERROR POR LIMITE"<<endl;
            cout<<"Con el limite de margen dado, es imposible acomodar algunas";
            cout<<endl<<"declaraciones de manera correcta.."<<endl;
            cout<<"Acciones recomendadas:"<<endl;
            cout<<"[A] Incrementar el limite de margen."<<endl;
            cout<<"[B] Desactivar el controlador de ajuste a margen."<<endl;
            cout<<"[C] Editar el archivo Fuente"<<endl;
            exit(1);
            break;
        case 'O':
            cout<<setw((med_Linea+30)/2)<<"ERROR POR TIPO DE ORDENAMIENTO";
            cout<<endl<<"El tipo de ordenamiento definido en los";
            cout<<"controladores,"<<endl<<"es invalido."<<endl;
            cout<<"Acciones recomendadas:"<<endl;
            cout<<"[A] Modificar el valor del controlador de tipo de";
            cout<<endl<<"    ordenamiento a alguno de los tipos predefinidos:";
            cout<<endl<<"    ['A'] Ascendente Jerarquico  [TP -> KW -> ID]";
            cout<<endl<<"    ['D'] Descendente Jerarquico [TP -> KW -> ID]";
            cout<<endl;
            exit(1);
            break;
        case 'P':
            cout<<setw((med_Linea+19)/2)<<"ERROR POR PARTICION"<<endl;
            cout<<"Se ha detectado una partición en un identificador de una";
            cout<<endl<<"declaración."<<endl;
            cout<<"Acciones recomendadas:"<<endl;
            cout<<"[A] Editar el archivo Fuente"<<endl;
            exit(1);
            break;
    }
}
