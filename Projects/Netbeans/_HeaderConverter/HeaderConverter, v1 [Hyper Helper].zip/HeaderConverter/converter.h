
/*/
 * Projecto:            HeaderConverter
 * Nombre del Archivo:  converter.h
 * Autor:               CyndxTs o.0?!
/*/

#ifndef CONVERTER_H
#define CONVERTER_H
#include "declaraciones.h"

        /* Controladores Del Programa */

// Controladores Generales
const bool ajustarHaciaMargen = true;       // Cuando se activa, las cabezeras no sobrepasaran el limite de margen designado
    const int limiteMargen = 79;                // Limite de margen designado
const bool ordenarDeclaraciones = false;    // Cuando se activa, las cabezeras son ordenadas por tipo y nombre respecto al ordenamiento designado
    const char tipoOrdenamiento = 'A';          // Tipo de Ordenamiento de Declaraciones 'A'scendente && 'D'escendente
// Controladores de Variables Globales
const bool mostrarVariablesGlobales = true; // Cuando se activa, las cabezeras de las variables globales se procesaran
// Controladores de Funciones
const bool mostrarFunciones = true;         // Cuando se activa, las cabezeras de las funciones se procesaran
    const bool suprimirVariables = true;        // Cuando se activa, los identificadores de las variables de los parametros de las funciones, no se mostrarán
    const char simboloLimite = ';';             // Simbolo limite de 'Impresion' de Funciones (Puede cambiarlo a '{' por ejm en caso quiera ajustar las cabezeras del cpp.)

        /* Declaracion de Constantes */

const KeyWord keyWords[num_KW] = {{false,"void"},{false,"LSE"},
                                  {false,"Declaracion"},{false,"Parametro"},
                                  {false,"Operador"},{false,"Operando"},
                                  {false,"KeyWord"},{false,"Asignacion"},
                                  {false,"Funcion"},{false,"ifstream"},
                                  {false,"ofstream"},{false,"fstream"},
                                  {false,"bool"},{false,"int"},
                                  {false,"double"},{false,"char"},
                                  {true,"const"},{true,"struct"},
                                  {true,"private"},{true,"public"},
                                  {false,{0}}};   // Puede añadir más en caso declare nuevas estructuras de datos!  {false,"NombreStruct"}

const Operador operators[num_OP] = {{true,"+"},{true,"-"},{true,"*"},
                                    {true,"/"},{true,":"},{true,"=="},
                                    {true,"!="},{true,">="},{true,"<="},
                                    {true,">"},{true,"<"},{false,"not"},
                                    {true,"!"},{false,"or"},{true,"||"},
                                    {false,"and"},{true,"&&"},{false,"xor"},
                                    {false,{0}}};

const char agrupadores[10][3] = {{'"','"',0},{39,39,0},{'(',')',0},{'[',']',0},
                                 {'{','}',0},{0}};
const char espaciadores[10] = {'\t','\n',' ',0};
const char modificadores[10] = {'&','*',0};
const char separadores[10] = {'\n',' ',',',';',0};

        /* Declaracion de Funciones */


void transcribirHaciaCabezera(ifstream &,ofstream &);

void procesarDeclaracion(ifstream &,LSE &,Declaracion &);

void imprimirLista(ofstream &,LSE);

void insertarOrdenado(LSE &,Declaracion);

void imprimirFuncion(ofstream &,Funcion);

void imprimirAsignacion(ofstream &,Asignacion);

bool procesarAjusteHaciaMargen(ofstream &,int,int,int &);

ifstream abrirArchivo_IFS(const char *);

ofstream abrirArchivo_OFS(const char *);

bool esAgrupador(char);

bool esAperturador(char);

bool esSeparador(char);

bool esDelimitador(char);

bool esEspaciador(char);

bool esModificador(char);

char obtenerAgrupadorInverso(char);

void obtenerParametros(ifstream &,Funcion &);

void obtenerParametros(ifstream &,Operando &);

void obtenerOperandos(ifstream &,Asignacion &);

void almacenarProximaKeyWord(ifstream &,char *,bool,bool);

void obtenerModificadoresDeKW(ifstream &,char *,bool);

void almacenarProximoIdentificador(ifstream &,Declaracion &);

void almacenarProximoIdentificador(ifstream &,bool,char *);

void almacenarProximoOperando(ifstream &,Operando &);

void separarOperadorDeIdentificador(Operando &,const char *);

void almacenarHastaDelimitador(ifstream &,char *,char,int &);

void descartarHastaDelimitador(ifstream &,char);

void procesarDescarteEspecial(ifstream &,char);

void validarDescartarPorComentario(ifstream &);

void emitirWarning(char);

#endif /* CONVERTER_H */
